from PyQt6 import QtCore, QtGui, QtWidgets
import csv

class Ui_JettsCalculator(object):
    def setupUi(self, JettsCalculator):
        JettsCalculator.setObjectName("JettsCalculator")
        JettsCalculator.setFixedSize(850, 390)


        # text for area buttons

        self.radio_circle = QtWidgets.QRadioButton(parent=JettsCalculator)
        self.radio_circle.setGeometry(QtCore.QRect(570, 30, 91, 20))
        self.radio_circle.setText("Circle")
        self.radio_circle.toggled.connect(lambda: self.toggle_inputs("circle"))

        self.radio_square = QtWidgets.QRadioButton(parent=JettsCalculator)
        self.radio_square.setGeometry(QtCore.QRect(570, 60, 91, 20))
        self.radio_square.setText("Square")
        self.radio_square.toggled.connect(lambda: self.toggle_inputs("square"))

        self.radio_rectangle = QtWidgets.QRadioButton(parent=JettsCalculator)
        self.radio_rectangle.setGeometry(QtCore.QRect(570, 90, 111, 20))
        self.radio_rectangle.setText("Rectangle")
        self.radio_rectangle.toggled.connect(lambda: self.toggle_inputs("rectangle"))

        self.radio_triangle = QtWidgets.QRadioButton(parent=JettsCalculator)
        self.radio_triangle.setGeometry(QtCore.QRect(570, 120, 91, 20))
        self.radio_triangle.setText("Triangle")
        self.radio_triangle.toggled.connect(lambda: self.toggle_inputs("triangle"))

        # new input fields for shape dimensions
        self.label_radius = QtWidgets.QLabel(parent=JettsCalculator)
        self.label_radius.setGeometry(QtCore.QRect(500, 210, 50, 22))
        self.label_radius.setText("Radius:")
        self.label_radius.setVisible(False)

        self.label_length = QtWidgets.QLabel(parent=JettsCalculator)
        self.label_length.setGeometry(QtCore.QRect(500, 210, 50, 22))
        self.label_length.setText("Length:")
        self.label_length.setVisible(False)

        self.label_width = QtWidgets.QLabel(parent=JettsCalculator)
        self.label_width.setGeometry(QtCore.QRect(500, 240, 50, 22))
        self.label_width.setText("Width:")
        self.label_width.setVisible(False)

        self.label_base = QtWidgets.QLabel(parent=JettsCalculator)
        self.label_base.setGeometry(QtCore.QRect(500, 210, 50, 22))
        self.label_base.setText("Base:")
        self.label_base.setVisible(False)

        self.label_height = QtWidgets.QLabel(parent=JettsCalculator)
        self.label_height.setGeometry(QtCore.QRect(500, 240, 50, 22))
        self.label_height.setText("Height:")
        self.label_height.setVisible(False)

        self.line_length = QtWidgets.QLineEdit(parent=JettsCalculator)
        self.line_length.setGeometry(QtCore.QRect(620, 210, 113, 22))
        self.line_length.setVisible(False)

        self.line_width = QtWidgets.QLineEdit(parent=JettsCalculator)
        self.line_width.setGeometry(QtCore.QRect(620, 240, 113, 22))
        self.line_width.setVisible(False)

        self.line_radius = QtWidgets.QLineEdit(parent=JettsCalculator)
        self.line_radius.setGeometry(QtCore.QRect(620, 210, 113, 22))
        self.line_radius.setVisible(False)

        self.line_base = QtWidgets.QLineEdit(parent=JettsCalculator)
        self.line_base.setGeometry(QtCore.QRect(620, 210, 113, 22))
        self.line_base.setVisible(False)

        self.line_height = QtWidgets.QLineEdit(parent=JettsCalculator)
        self.line_height.setGeometry(QtCore.QRect(620, 240, 113, 22))
        self.line_height.setVisible(False)

        # submit button
        self.button_submit = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_submit.setGeometry(QtCore.QRect(580, 280, 93, 28))
        self.button_submit.setText("Submit")
        self.button_submit.clicked.connect(self.calculate_area)

        # clear button
        self.button_clear = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_clear.setGeometry(QtCore.QRect(680, 280, 93, 28))
        self.button_clear.setText("Clear")
        self.button_clear.clicked.connect(self.clear_fields)

        # result display box
        self.line_result = QtWidgets.QLineEdit(parent=JettsCalculator)
        self.line_result.setGeometry(QtCore.QRect(550, 320, 231, 22))

        # assigns buttons (pyQT)

        self.button_0 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_0.setGeometry(QtCore.QRect(130, 210, 75, 41))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.button_0.setFont(font)
        self.button_0.setObjectName("button_0")
        self.button_decimal = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_decimal.setGeometry(QtCore.QRect(220, 210, 75, 41))
        self.button_decimal.setObjectName("button_decimal")
        self.button_pos_neg = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_pos_neg.setGeometry(QtCore.QRect(310, 210, 75, 41))
        self.button_pos_neg.setObjectName("button_pos_neg")
        self.button_1 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_1.setGeometry(QtCore.QRect(130, 160, 75, 41))
        self.button_1.setObjectName("button_1")
        self.button_2 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_2.setGeometry(QtCore.QRect(220, 162, 75, 41))
        self.button_2.setObjectName("button_2")
        self.button_3 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_3.setGeometry(QtCore.QRect(310, 162, 75, 41))
        self.button_3.setObjectName("button_3")
        self.button_4 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_4.setGeometry(QtCore.QRect(130, 112, 75, 41))
        self.button_4.setObjectName("button_4")
        self.button_5 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_5.setGeometry(QtCore.QRect(220, 112, 75, 41))
        self.button_5.setObjectName("button_5")
        self.button_6 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_6.setGeometry(QtCore.QRect(310, 112, 75, 41))
        self.button_6.setObjectName("button_6")
        self.button_equal = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_equal.setGeometry(QtCore.QRect(220, 270, 75, 31))
        font = QtGui.QFont()
        font.setBold(False)
        font.setWeight(50)
        self.button_equal.setFont(font)
        self.button_equal.setObjectName("button_equal")
        self.button_add = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_add.setGeometry(QtCore.QRect(400, 220, 75, 41))
        self.button_add.setObjectName("button_add")
        self.button_subtract = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_subtract.setGeometry(QtCore.QRect(400, 170, 75, 41))
        self.button_subtract.setObjectName("button_subtract")
        self.button_multiply = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_multiply.setGeometry(QtCore.QRect(400, 120, 75, 41))
        self.button_multiply.setObjectName("button_multiply")
        self.button_divide = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_divide.setGeometry(QtCore.QRect(400, 70, 75, 41))
        self.button_divide.setObjectName("button_divide")
        self.button_percent = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_percent.setGeometry(QtCore.QRect(30, 112, 75, 41))
        self.button_percent.setObjectName("button_percent")
        self.button_square = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_square.setGeometry(QtCore.QRect(30, 170, 75, 41))
        self.button_square.setObjectName("button_square")
        self.button_power = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_power.setGeometry(QtCore.QRect(30, 270, 75, 31))
        self.button_power.setObjectName("button_power")
        self.button_7 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_7.setGeometry(QtCore.QRect(130, 70, 75, 41))
        self.button_7.setObjectName("button_7")
        self.button_8 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_8.setGeometry(QtCore.QRect(220, 70, 75, 41))
        self.button_8.setObjectName("button_8")
        self.button_9 = QtWidgets.QPushButton(parent=JettsCalculator)
        self.button_9.setGeometry(QtCore.QRect(310, 70, 75, 41))
        self.button_9.setObjectName("button_9")
        self.line_calc = QtWidgets.QLineEdit(parent=JettsCalculator)
        self.line_calc.setGeometry(QtCore.QRect(140, 20, 261, 41))
        self.line_calc.setObjectName("line_calc")
        self.textEdit = QtWidgets.QLabel(parent=JettsCalculator)
        self.textEdit.setGeometry(QtCore.QRect(20, 20, 111, 51))
        font = QtGui.QFont()
        font.setPointSize(10)
        font.setBold(True)
        font.setWeight(75)
        self.textEdit.setFont(font)
        self.textEdit.setObjectName("textEdit")

        self.retranslateUi(JettsCalculator)
        QtCore.QMetaObject.connectSlotsByName(JettsCalculator)

    # saves results of area calculations to the csv

    def save_to_csv(self, calculation):
        try:
            with open("calculator_results.csv", mode="a", newline="") as file:
                writer = csv.writer(file)
                writer.writerow([calculation])
        except Exception as e:
            print("Error occurred while saving to CSV:", e)

    def toggle_inputs(self, shape):
        # hide all input fields and labels first
        self.label_radius.setVisible(False)
        self.label_length.setVisible(False)
        self.label_width.setVisible(False)
        self.label_base.setVisible(False)
        self.label_height.setVisible(False)

        self.line_length.setVisible(False)
        self.line_width.setVisible(False)
        self.line_radius.setVisible(False)
        self.line_base.setVisible(False)
        self.line_height.setVisible(False)

        # based on the selected shape, show the corresponding input fields and labels
        if shape == "circle":
            self.label_radius.setVisible(True)
            self.line_radius.setVisible(True)
        elif shape == "square":
            self.label_length.setVisible(True)
            self.line_length.setVisible(True)
        elif shape == "rectangle":
            self.label_length.setVisible(True)
            self.label_width.setVisible(True)
            self.line_length.setVisible(True)
            self.line_width.setVisible(True)
        elif shape == "triangle":
            self.label_base.setVisible(True)
            self.label_height.setVisible(True)
            self.line_base.setVisible(True)
            self.line_height.setVisible(True)

    # calculations for the areas of each shape

    def calculate_area(self):
        if self.radio_circle.isChecked():
            if self.line_radius.text().strip():
                radius = float(self.line_radius.text())
                area = 3.14159 * (radius ** 2)
                self.line_result.setText(str(area))
                self.save_to_csv(f"Circle: Radius={radius}, Area={area}")
            else:
                self.line_result.setText("Please enter a value")
        elif self.radio_square.isChecked():
            if self.line_length.text().strip():
                length = float(self.line_length.text())
                area = length ** 2
                self.line_result.setText(str(area))
                self.save_to_csv(f"Square: Length={length}, Area={area}")
            else:
                self.line_result.setText("Please enter a value")
        elif self.radio_rectangle.isChecked():
            if self.line_length.text().strip() and self.line_width.text().strip():
                length = float(self.line_length.text())
                width = float(self.line_width.text())
                area = length * width
                self.line_result.setText(str(area))
                self.save_to_csv(f"Rectangle: Length={length}, Width={width}, Area={area}")

            else:
                self.line_result.setText("Enter values for length and width")
        elif self.radio_triangle.isChecked():
            if self.line_base.text().strip() and self.line_height.text().strip():
                base = float(self.line_base.text())
                height = float(self.line_height.text())
                area = 0.5 * base * height
                self.line_result.setText(str(area))
                self.save_to_csv(f"Triangle: Base={base}, Height={height}, Area={area}")
            else:
                self.line_result.setText("Enter values for base and height")

    # clears input boxes

    def clear_fields(self):
        self.line_radius.clear()
        self.line_length.clear()
        self.line_width.clear()
        self.line_base.clear()
        self.line_height.clear()
        self.line_result.clear()

    def retranslateUi(self, JettsCalculator):
        _translate = QtCore.QCoreApplication.translate
        JettsCalculator.setWindowTitle(_translate("JettsCalculator", "Jett\'s Calculator"))
        self.button_0.setText(_translate("JettsCalculator", "PushButton"))
        self.button_decimal.setText(_translate("JettsCalculator", "PushButton"))
        self.button_pos_neg.setText(_translate("JettsCalculator", "PushButton"))
        self.button_1.setText(_translate("JettsCalculator", "PushButton"))
        self.button_2.setText(_translate("JettsCalculator", "PushButton"))
        self.button_3.setText(_translate("JettsCalculator", "PushButton"))
        self.button_4.setText(_translate("JettsCalculator", "PushButton"))
        self.button_5.setText(_translate("JettsCalculator", "PushButton"))
        self.button_6.setText(_translate("JettsCalculator", "PushButton"))
        self.button_equal.setText(_translate("JettsCalculator", "PushButton"))
        self.button_add.setText(_translate("JettsCalculator", "PushButton"))
        self.button_subtract.setText(_translate("JettsCalculator", "PushButton"))
        self.button_multiply.setText(_translate("JettsCalculator", "PushButton"))
        self.button_divide.setText(_translate("JettsCalculator", "PushButton"))
        self.button_percent.setText(_translate("JettsCalculator", "PushButton"))
        self.button_square.setText(_translate("JettsCalculator", "PushButton"))
        self.button_power.setText(_translate("JettsCalculator", "PushButton"))
        self.button_7.setText(_translate("JettsCalculator", "PushButton"))
        self.button_8.setText(_translate("JettsCalculator", "PushButton"))
        self.button_9.setText(_translate("JettsCalculator", "PushButton"))
        self.button_clear.setText(_translate("JettsCalculator", "PushButton"))
        self.textEdit.setText(_translate("JettsCalculator", "Jett\'s Calculator!"))


if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    JettsCalculator = QtWidgets.QDialog()
    ui = Ui_JettsCalculator()
    ui.setupUi(JettsCalculator)
    JettsCalculator.show()
    sys.exit(app.exec())
