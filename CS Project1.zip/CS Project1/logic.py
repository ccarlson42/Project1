from PyQt6.QtWidgets import QDialog
from gui import Ui_JettsCalculator
import math

class Logic(QDialog):
    def __init__(self):
        super().__init__()
        self.init_ui()
        self.last_clicked_button = None

    def init_ui(self):
        self.ui = Ui_JettsCalculator()
        self.ui.setupUi(self)

        # text for buttons
        # connect buttons
        self.ui.button_0.setText("0")
        self.ui.button_1.setText("1")
        self.ui.button_2.setText("2")
        self.ui.button_3.setText("3")
        self.ui.button_4.setText("4")
        self.ui.button_5.setText("5")
        self.ui.button_6.setText("6")
        self.ui.button_7.setText("7")
        self.ui.button_8.setText("8")
        self.ui.button_9.setText("9")
        self.ui.button_equal.setText("=")
        self.ui.button_add.setText("+")
        self.ui.button_subtract.setText("-")
        self.ui.button_multiply.setText("*")
        self.ui.button_divide.setText("/")
        self.ui.button_percent.setText("%")
        self.ui.button_square.setText("Sqrt")
        self.ui.button_power.setText("^")
        self.ui.button_pos_neg.setText("±")
        self.ui.button_decimal.setText(".")
        self.ui.button_clear.setText("CLEAR")

        self.ui.button_0.clicked.connect(lambda: self.number_clicked("0"))
        self.ui.button_1.clicked.connect(lambda: self.number_clicked("1"))
        self.ui.button_2.clicked.connect(lambda: self.number_clicked("2"))
        self.ui.button_3.clicked.connect(lambda: self.number_clicked("3"))
        self.ui.button_4.clicked.connect(lambda: self.number_clicked("4"))
        self.ui.button_5.clicked.connect(lambda: self.number_clicked("5"))
        self.ui.button_6.clicked.connect(lambda: self.number_clicked("6"))
        self.ui.button_7.clicked.connect(lambda: self.number_clicked("7"))
        self.ui.button_8.clicked.connect(lambda: self.number_clicked("8"))
        self.ui.button_9.clicked.connect(lambda: self.number_clicked("9"))
        self.ui.button_equal.clicked.connect(self.button_equal_clicked)
        self.ui.button_add.clicked.connect(lambda: self.handle_operator("+"))
        self.ui.button_subtract.clicked.connect(lambda: self.handle_operator("-"))
        self.ui.button_multiply.clicked.connect(lambda: self.handle_operator("*"))
        self.ui.button_divide.clicked.connect(lambda: self.handle_operator("/"))
        self.ui.button_percent.clicked.connect(self.button_percent_clicked)
        self.ui.button_square.clicked.connect(self.button_square_clicked)
        self.ui.button_power.clicked.connect(lambda: self.handle_operator("**"))
        self.ui.button_pos_neg.clicked.connect(self.button_pos_neg_clicked)
        self.ui.button_decimal.clicked.connect(self.button_decimal_clicked)
        self.ui.button_clear.clicked.connect(self.clear_display)

        self.num_display = ""
        self.result = None
        self.operator = None
#functions for calculations/purpose of operators
    def number_clicked(self, num):
        if self.last_clicked_button == "±":
            if num.startswith("-"):
                num = num[1:]
            else:
                num = "-" + num
        self.num_display += num
        self.update_display()
        self.last_clicked_button = num

    # equal button
    def button_equal_clicked(self):
        if self.operator and self.num_display:
            try:
                result = eval(f"{self.result}{self.operator}{self.num_display}")
                self.num_display = str(result)
                self.result = result
                self.update_display()
            except Exception as e:
                self.ui.line_calc.setText("Error")
        else:
            self.ui.line_calc.setText("Error: Enter a number first")
        self.num_display = ""

# modulo
    def button_percent_clicked(self):
        if self.num_display:
            if self.result is None:
                self.result = self.num_display
                self.operator = "%"
                self.num_display = ""
                self.update_display()
            else:
                try:
                    self.result = eval(f"{self.result}{self.operator}{self.num_display}")
                    self.num_display = ""
                    self.update_display()
                except Exception as e:
                    self.ui.line_calc.setText("Error")
        else:
            self.ui.line_calc.setText("Error: Enter a number first")

# finds square root
    def button_square_clicked(self):
        if self.num_display:
            num = float(self.num_display)
            if num <= 0:
                self.ui.line_calc.setText("Error: can't square root")
            else:
                result = math.sqrt(num)
                self.ui.line_calc.setText(str(result))
        else:
            self.ui.line_calc.setText("Error: Enter a number first")
# positive or negative
    def button_pos_neg_clicked(self):
        if self.num_display:
            if self.num_display.startswith("-"):
                self.num_display = self.num_display[1:]
            else:
                self.num_display = "-" + self.num_display
            self.update_display()
        else:
            self.ui.line_calc.setText("Error: Enter a number first")
# decimal
    def button_decimal_clicked(self):
        if "." not in self.num_display:
            self.num_display += "."
            self.update_display()
        else:
            self.ui.line_calc.setText("Error: Enter a number first")
# handling
    def handle_operator(self, op):
        if self.num_display:
            if self.result is None:
                self.result = self.num_display
            else:
                try:
                    if self.operator:
                        self.result = eval(f"{self.result}{self.operator}{self.num_display}")
                    else:
                        self.result = self.num_display
                except Exception as e:
                    self.ui.line_calc.setText("Error")
                    self.result = None
            self.operator = op
            self.num_display = ""
            self.update_display()
# clear
    def clear_display(self):
        self.num_display = ""
        self.result = None
        self.operator = None
        self.update_display()

    def update_display(self):
        self.ui.line_calc.setText(self.num_display)
